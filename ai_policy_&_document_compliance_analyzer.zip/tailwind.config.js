/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#4f46e5',
          hover: '#4338ca',
        },
        secondary: '#64748b',
        // VIBGYOR theme colors
        violet: {
          50: '#f5f3ff',
          100: '#ede9fe',
          200: '#ddd6fe',
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
          700: '#6d28d9',
          800: '#5b21b6',
          900: '#4c1d95',
        },
        indigo: {
          50: '#eef2ff',
          100: '#e0e7ff',
          200: '#c7d2fe',
          300: '#a5b4fc',
          400: '#818cf8',
          500: '#6366f1',
          600: '#4f46e5',
          700: '#4338ca',
          800: '#3730a3',
          900: '#312e81',
        },
      },
      spacing: {
        'section': '2rem',
        'container': '1rem',
      },
      borderRadius: {
        'container': '0.75rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
  safelist: [
    // Risk level colors
    'bg-red-100', 'text-red-700', 'border-red-500', 'bg-red-500', 'text-red-600', 'text-red-800',
    'bg-orange-100', 'text-orange-700', 'border-orange-500', 'bg-orange-500', 'text-orange-600', 'text-orange-800',
    'bg-yellow-100', 'text-yellow-700', 'border-yellow-500', 'bg-yellow-500', 'text-yellow-600', 'text-yellow-800',
    'bg-green-100', 'text-green-700', 'border-green-500', 'bg-green-500', 'text-green-600', 'text-green-800',
    'bg-blue-100', 'text-blue-700', 'border-blue-500', 'bg-blue-500', 'text-blue-600', 'text-blue-800',
    'bg-indigo-100', 'text-indigo-700', 'border-indigo-500', 'bg-indigo-500', 'text-indigo-600', 'text-indigo-800',
    'bg-violet-100', 'text-violet-700', 'border-violet-500', 'bg-violet-500', 'text-violet-600', 'text-violet-800',
    'bg-slate-100', 'text-slate-700', 'border-slate-500', 'bg-slate-500', 'text-slate-600', 'text-slate-800',
  ],
}

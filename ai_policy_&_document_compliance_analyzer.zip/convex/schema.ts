import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User profiles with role-based access
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.union(v.literal("admin"), v.literal("reviewer"), v.literal("viewer")),
    department: v.optional(v.string()),
    createdAt: v.number(),
  }).index("by_user", ["userId"]),

  // Document storage and metadata
  documents: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    fileId: v.id("_storage"),
    fileType: v.union(v.literal("pdf"), v.literal("docx")),
    uploadedBy: v.id("users"),
    extractedText: v.optional(v.string()),
    status: v.union(
      v.literal("uploaded"),
      v.literal("processing"),
      v.literal("analyzed"),
      v.literal("error")
    ),
    version: v.number(),
    parentDocumentId: v.optional(v.id("documents")),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_uploader", ["uploadedBy"])
    .index("by_status", ["status"])
    .index("by_parent", ["parentDocumentId"]),

  // AI compliance analysis results
  complianceAnalysis: defineTable({
    documentId: v.id("documents"),
    overallScore: v.number(), // 0-100
    riskLevel: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    analysisDate: v.number(),
    aiModel: v.string(),
    executiveSummary: v.string(),
  }).index("by_document", ["documentId"]),

  // Individual clause analysis
  clauseAnalysis: defineTable({
    analysisId: v.id("complianceAnalysis"),
    documentId: v.id("documents"),
    clauseText: v.string(),
    startPosition: v.number(),
    endPosition: v.number(),
    riskLevel: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
    riskScore: v.number(), // 0-100
    category: v.string(), // e.g., "Data Privacy", "Employment", "Financial"
    issues: v.array(v.string()),
    recommendations: v.array(v.string()),
    aiExplanation: v.string(),
  })
    .index("by_analysis", ["analysisId"])
    .index("by_document", ["documentId"])
    .index("by_risk", ["riskLevel"]),

  // Regulatory frameworks for comparison
  regulatoryFrameworks: defineTable({
    name: v.string(),
    description: v.string(),
    category: v.string(),
    requirements: v.array(v.object({
      title: v.string(),
      description: v.string(),
      mandatory: v.boolean(),
      sampleClause: v.optional(v.string()),
    })),
    createdBy: v.id("users"),
    isActive: v.boolean(),
    createdAt: v.number(),
  }).index("by_category", ["category"]),

  // Framework comparison results
  frameworkComparisons: defineTable({
    documentId: v.id("documents"),
    frameworkId: v.id("regulatoryFrameworks"),
    complianceScore: v.number(), // 0-100
    missingRequirements: v.array(v.string()),
    partialCompliance: v.array(v.object({
      requirement: v.string(),
      reason: v.string(),
      suggestion: v.string(),
    })),
    fullCompliance: v.array(v.string()),
    analysisDate: v.number(),
  })
    .index("by_document", ["documentId"])
    .index("by_framework", ["frameworkId"]),

  // Audit reports
  auditReports: defineTable({
    documentId: v.id("documents"),
    title: v.string(),
    reportType: v.union(v.literal("compliance"), v.literal("risk"), v.literal("executive")),
    generatedBy: v.id("users"),
    reportData: v.object({
      summary: v.string(),
      keyFindings: v.array(v.string()),
      recommendations: v.array(v.string()),
      riskBreakdown: v.object({
        high: v.number(),
        medium: v.number(),
        low: v.number(),
      }),
    }),
    fileId: v.optional(v.id("_storage")), // PDF export
    createdAt: v.number(),
  })
    .index("by_document", ["documentId"])
    .index("by_generator", ["generatedBy"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});

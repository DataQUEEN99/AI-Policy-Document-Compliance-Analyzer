import { v } from "convex/values";
import { mutation, query, action, internalMutation, internalAction } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

export const createDocument = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    fileId: v.id("_storage"),
    fileType: v.union(v.literal("pdf"), v.literal("docx")),
    parentDocumentId: v.optional(v.id("documents")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Check user permissions
    const profile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!profile || profile.role === "viewer") {
      throw new Error("Insufficient permissions to upload documents");
    }

    const version = args.parentDocumentId ? 
      await getNextVersion(ctx, args.parentDocumentId) : 1;

    const documentId = await ctx.db.insert("documents", {
      title: args.title,
      description: args.description,
      fileId: args.fileId,
      fileType: args.fileType,
      uploadedBy: userId,
      status: "uploaded",
      version,
      parentDocumentId: args.parentDocumentId,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });

    // Schedule text extraction and analysis
    await ctx.scheduler.runAfter(0, internal.documents.processDocument, {
      documentId,
    });

    return documentId;
  },
});

async function getNextVersion(ctx: any, parentDocumentId: string): Promise<number> {
  const versions = await ctx.db
    .query("documents")
    .withIndex("by_parent", (q: any) => q.eq("parentDocumentId", parentDocumentId))
    .collect();
  
  const maxVersion = Math.max(...versions.map((v: any) => v.version), 0);
  return maxVersion + 1;
}

export const processDocument = internalAction({
  args: {
    documentId: v.id("documents"),
  },
  handler: async (ctx, args) => {
    // Update status to processing
    await ctx.runMutation(internal.documents.updateDocumentStatus, {
      documentId: args.documentId,
      status: "processing",
    });

    try {
      // In a real implementation, you would extract text from PDF/DOCX here
      // For now, we'll simulate with placeholder text
      const extractedText = "Sample policy document text for analysis...";

      await ctx.runMutation(internal.documents.updateDocumentText, {
        documentId: args.documentId,
        extractedText,
      });

      // Trigger AI analysis
      await ctx.scheduler.runAfter(0, internal.analysis.analyzeDocument, {
        documentId: args.documentId,
      });

    } catch (error) {
      await ctx.runMutation(internal.documents.updateDocumentStatus, {
        documentId: args.documentId,
        status: "error",
      });
      throw error;
    }
  },
});

export const updateDocumentStatus = internalMutation({
  args: {
    documentId: v.id("documents"),
    status: v.union(
      v.literal("uploaded"),
      v.literal("processing"),
      v.literal("analyzed"),
      v.literal("error")
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.documentId, {
      status: args.status,
      updatedAt: Date.now(),
    });
  },
});

export const updateDocumentText = internalMutation({
  args: {
    documentId: v.id("documents"),
    extractedText: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.documentId, {
      extractedText: args.extractedText,
      updatedAt: Date.now(),
    });
  },
});

export const getDocuments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const documents = await ctx.db.query("documents").order("desc").collect();
    
    return await Promise.all(
      documents.map(async (doc) => {
        const uploader = await ctx.db.get(doc.uploadedBy);
        const fileUrl = await ctx.storage.getUrl(doc.fileId);
        
        // Get latest analysis if available
        const analysis = await ctx.db
          .query("complianceAnalysis")
          .withIndex("by_document", (q) => q.eq("documentId", doc._id))
          .order("desc")
          .first();

        return {
          ...doc,
          uploader,
          fileUrl,
          analysis,
        };
      })
    );
  },
});

export const getDocument = query({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const document = await ctx.db.get(args.documentId);
    if (!document) {
      throw new Error("Document not found");
    }

    const uploader = await ctx.db.get(document.uploadedBy);
    const fileUrl = await ctx.storage.getUrl(document.fileId);

    return {
      ...document,
      uploader,
      fileUrl,
    };
  },
});

export const getDocumentVersions = query({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const document = await ctx.db.get(args.documentId);
    if (!document) {
      throw new Error("Document not found");
    }

    // Get all versions of this document
    const versions = await ctx.db
      .query("documents")
      .withIndex("by_parent", (q) => q.eq("parentDocumentId", document.parentDocumentId || args.documentId))
      .order("desc")
      .collect();

    return await Promise.all(
      versions.map(async (version) => {
        const uploader = await ctx.db.get(version.uploadedBy);
        const analysis = await ctx.db
          .query("complianceAnalysis")
          .withIndex("by_document", (q) => q.eq("documentId", version._id))
          .order("desc")
          .first();

        return {
          ...version,
          uploader,
          analysis,
        };
      })
    );
  },
});

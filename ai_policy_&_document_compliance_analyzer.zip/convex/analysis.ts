import { v } from "convex/values";
import { action, mutation, query, internalMutation, internalQuery, internalAction } from "./_generated/server";
import { internal } from "./_generated/api";

export const analyzeDocument = internalAction({
  args: {
    documentId: v.id("documents"),
  },
  handler: async (ctx, args): Promise<string> => {
    const document = await ctx.runQuery(internal.analysis.getDocumentForAnalysis, {
      documentId: args.documentId,
    });

    if (!document || !document.extractedText) {
      throw new Error("Document not ready for analysis");
    }

    try {
      // AI-powered compliance analysis using OpenAI
      const analysisResult = await performAIAnalysis(document.extractedText);

      // Store the analysis results
      const analysisId: string = await ctx.runMutation(internal.analysis.storeAnalysis, {
        documentId: args.documentId,
        analysisResult,
      });

      // Update document status
      await ctx.runMutation(internal.documents.updateDocumentStatus, {
        documentId: args.documentId,
        status: "analyzed",
      });

      return analysisId;
    } catch (error) {
      await ctx.runMutation(internal.documents.updateDocumentStatus, {
        documentId: args.documentId,
        status: "error",
      });
      throw error;
    }
  },
});

async function performAIAnalysis(documentText: string) {
  // This would use the built-in OpenAI integration
  // For now, we'll return mock analysis data
  return {
    overallScore: Math.floor(Math.random() * 40) + 60, // 60-100
    riskLevel: ["low", "medium", "high"][Math.floor(Math.random() * 3)] as "low" | "medium" | "high",
    executiveSummary: "This document demonstrates good compliance practices with some areas for improvement. Key strengths include clear data handling procedures and employee rights documentation. Areas requiring attention include incident response protocols and third-party vendor management clauses.",
    clauses: [
      {
        text: "Employee data shall be processed in accordance with applicable privacy laws",
        startPosition: 0,
        endPosition: 70,
        riskLevel: "low" as const,
        riskScore: 25,
        category: "Data Privacy",
        issues: [],
        recommendations: ["Consider adding specific retention periods", "Include data subject rights"],
        explanation: "This clause provides basic privacy compliance but could be more specific about retention and subject rights."
      },
      {
        text: "Company reserves the right to monitor employee communications",
        startPosition: 100,
        endPosition: 165,
        riskLevel: "high" as const,
        riskScore: 85,
        category: "Employment",
        issues: ["Overly broad monitoring rights", "Lacks employee consent provisions"],
        recommendations: ["Add specific monitoring limitations", "Include employee notification requirements", "Define legitimate business purposes"],
        explanation: "This clause presents high privacy risks due to broad monitoring rights without adequate safeguards or employee protections."
      },
      {
        text: "Financial records must be maintained for a minimum of 7 years",
        startPosition: 200,
        endPosition: 260,
        riskLevel: "medium" as const,
        riskScore: 45,
        category: "Financial",
        issues: ["Missing digital record specifications"],
        recommendations: ["Specify digital vs physical record requirements", "Add secure disposal procedures"],
        explanation: "Good retention period but needs clarification on digital record handling and secure disposal methods."
      }
    ]
  };
}

export const getDocumentForAnalysis = internalQuery({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.documentId);
  },
});

export const storeAnalysis = internalMutation({
  args: {
    documentId: v.id("documents"),
    analysisResult: v.object({
      overallScore: v.number(),
      riskLevel: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
      executiveSummary: v.string(),
      clauses: v.array(v.object({
        text: v.string(),
        startPosition: v.number(),
        endPosition: v.number(),
        riskLevel: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
        riskScore: v.number(),
        category: v.string(),
        issues: v.array(v.string()),
        recommendations: v.array(v.string()),
        explanation: v.string(),
      })),
    }),
  },
  handler: async (ctx, args) => {
    const analysisId = await ctx.db.insert("complianceAnalysis", {
      documentId: args.documentId,
      overallScore: args.analysisResult.overallScore,
      riskLevel: args.analysisResult.riskLevel,
      analysisDate: Date.now(),
      aiModel: "gpt-4.1-nano",
      executiveSummary: args.analysisResult.executiveSummary,
    });

    // Store individual clause analyses
    for (const clause of args.analysisResult.clauses) {
      await ctx.db.insert("clauseAnalysis", {
        analysisId,
        documentId: args.documentId,
        clauseText: clause.text,
        startPosition: clause.startPosition,
        endPosition: clause.endPosition,
        riskLevel: clause.riskLevel,
        riskScore: clause.riskScore,
        category: clause.category,
        issues: clause.issues,
        recommendations: clause.recommendations,
        aiExplanation: clause.explanation,
      });
    }

    return analysisId;
  },
});

export const getAnalysis = query({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    const analysis = await ctx.db
      .query("complianceAnalysis")
      .withIndex("by_document", (q) => q.eq("documentId", args.documentId))
      .order("desc")
      .first();

    if (!analysis) {
      return null;
    }

    const clauses = await ctx.db
      .query("clauseAnalysis")
      .withIndex("by_analysis", (q) => q.eq("analysisId", analysis._id))
      .collect();

    return {
      ...analysis,
      clauses,
    };
  },
});

export const getDashboardStats = query({
  args: {},
  handler: async (ctx) => {
    const documents = await ctx.db.query("documents").collect();
    const analyses = await ctx.db.query("complianceAnalysis").collect();
    const clauses = await ctx.db.query("clauseAnalysis").collect();

    const totalDocuments = documents.length;
    const analyzedDocuments = documents.filter(d => d.status === "analyzed").length;
    
    const riskBreakdown = {
      high: clauses.filter(c => c.riskLevel === "high").length,
      medium: clauses.filter(c => c.riskLevel === "medium").length,
      low: clauses.filter(c => c.riskLevel === "low").length,
    };

    const avgComplianceScore = analyses.length > 0 
      ? analyses.reduce((sum, a) => sum + a.overallScore, 0) / analyses.length 
      : 0;

    const recentAnalyses = analyses
      .sort((a, b) => b.analysisDate - a.analysisDate)
      .slice(0, 5);

    return {
      totalDocuments,
      analyzedDocuments,
      riskBreakdown,
      avgComplianceScore: Math.round(avgComplianceScore),
      recentAnalyses,
    };
  },
});

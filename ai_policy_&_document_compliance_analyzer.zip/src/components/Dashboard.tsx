import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignOutButton } from "../SignOutButton";
import { DocumentUpload } from "./DocumentUpload";
import { DocumentList } from "./DocumentList";
import { AnalyticsDashboard } from "./AnalyticsDashboard";
import { DocumentAnalysis } from "./DocumentAnalysis";

type View = "dashboard" | "documents" | "upload" | "analysis";

interface DashboardProps {
  userProfile: any;
}

export function Dashboard({ userProfile }: DashboardProps) {
  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [selectedDocumentId, setSelectedDocumentId] = useState<string | null>(null);

  const stats = useQuery(api.analysis.getDashboardStats);

  const navigation = [
    {
      id: "dashboard" as const,
      name: "Dashboard",
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z" />
        </svg>
      ),
      color: "indigo",
    },
    {
      id: "documents" as const,
      name: "Documents",
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      ),
      color: "blue",
    },
    {
      id: "upload" as const,
      name: "Upload",
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
      ),
      color: "green",
      hidden: userProfile.role === "viewer",
    },
  ];

  const handleDocumentSelect = (documentId: string) => {
    setSelectedDocumentId(documentId);
    setCurrentView("analysis");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-indigo-100 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-violet-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                ComplianceAI
              </h1>
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-sm text-slate-600">
                <span className="font-medium">{userProfile.user?.email}</span>
                <span className="ml-2 px-2 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-medium capitalize">
                  {userProfile.role}
                </span>
              </div>
              <SignOutButton />
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white/60 backdrop-blur-sm border-r border-indigo-100 min-h-screen p-4">
          <div className="space-y-2">
            {navigation.filter(item => !item.hidden).map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                  currentView === item.id
                    ? `bg-${item.color}-100 text-${item.color}-700 shadow-sm`
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                {item.icon}
                <span className="font-medium">{item.name}</span>
              </button>
            ))}
          </div>

          {/* Quick Stats */}
          {stats && (
            <div className="mt-8 p-4 bg-white/80 rounded-lg border border-slate-200">
              <h3 className="text-sm font-semibold text-slate-700 mb-3">Quick Stats</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Documents</span>
                  <span className="font-medium">{stats.totalDocuments}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Analyzed</span>
                  <span className="font-medium">{stats.analyzedDocuments}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Avg Score</span>
                  <span className="font-medium">{stats.avgComplianceScore}%</span>
                </div>
              </div>
            </div>
          )}
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {currentView === "dashboard" && <AnalyticsDashboard stats={stats} />}
          {currentView === "documents" && (
            <DocumentList onDocumentSelect={handleDocumentSelect} />
          )}
          {currentView === "upload" && <DocumentUpload />}
          {currentView === "analysis" && selectedDocumentId && (
            <DocumentAnalysis 
              documentId={selectedDocumentId} 
              onBack={() => setCurrentView("documents")}
            />
          )}
        </main>
      </div>
    </div>
  );
}

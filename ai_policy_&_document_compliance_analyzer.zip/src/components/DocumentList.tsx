import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface DocumentListProps {
  onDocumentSelect: (documentId: string) => void;
}

export function DocumentList({ onDocumentSelect }: DocumentListProps) {
  const documents = useQuery(api.documents.getDocuments);

  if (documents === undefined) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "analyzed": return "green";
      case "processing": return "yellow";
      case "error": return "red";
      default: return "blue";
    }
  };

  const getRiskColor = (riskLevel?: string) => {
    switch (riskLevel) {
      case "high": return "red";
      case "medium": return "orange";
      case "low": return "green";
      default: return "slate";
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Document Library</h2>
        <p className="text-slate-600">Manage and analyze your policy documents</p>
      </div>

      {documents.length === 0 ? (
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-12 border border-slate-200 text-center">
          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-slate-800 mb-2">No documents yet</h3>
          <p className="text-slate-600">Upload your first policy document to get started with compliance analysis.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {documents.map((document) => (
            <div
              key={document._id}
              className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-slate-200 hover:shadow-lg transition-all duration-200 cursor-pointer"
              onClick={() => onDocumentSelect(document._id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold text-slate-800">{document.title}</h3>
                    <span className={`px-2 py-1 bg-${getStatusColor(document.status)}-100 text-${getStatusColor(document.status)}-700 rounded-full text-xs font-medium capitalize`}>
                      {document.status}
                    </span>
                    {document.analysis && (
                      <span className={`px-2 py-1 bg-${getRiskColor(document.analysis.riskLevel)}-100 text-${getRiskColor(document.analysis.riskLevel)}-700 rounded-full text-xs font-medium`}>
                        {document.analysis.riskLevel} Risk
                      </span>
                    )}
                  </div>
                  
                  {document.description && (
                    <p className="text-slate-600 mb-3">{document.description}</p>
                  )}
                  
                  <div className="flex items-center space-x-4 text-sm text-slate-500">
                    <span>Uploaded by {document.uploader?.email}</span>
                    <span>•</span>
                    <span>{new Date(document.createdAt).toLocaleDateString()}</span>
                    <span>•</span>
                    <span className="uppercase">{document.fileType}</span>
                    {document.version > 1 && (
                      <>
                        <span>•</span>
                        <span>v{document.version}</span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  {document.analysis && (
                    <div className="text-right">
                      <div className="text-2xl font-bold text-slate-800">{document.analysis.overallScore}%</div>
                      <div className="text-xs text-slate-500">Compliance</div>
                    </div>
                  )}
                  
                  <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>

              {document.analysis && (
                <div className="mt-4 pt-4 border-t border-slate-200">
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full bg-${
                        document.analysis.overallScore >= 80 ? 'green' :
                        document.analysis.overallScore >= 60 ? 'yellow' : 'red'
                      }-500`}
                      style={{ width: `${document.analysis.overallScore}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

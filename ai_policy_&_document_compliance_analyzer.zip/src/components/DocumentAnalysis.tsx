import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface DocumentAnalysisProps {
  documentId: string;
  onBack: () => void;
}

export function DocumentAnalysis({ documentId, onBack }: DocumentAnalysisProps) {
  const document = useQuery(api.documents.getDocument, { documentId: documentId as any });
  const analysis = useQuery(api.analysis.getAnalysis, { documentId: documentId as any });

  if (document === undefined || analysis === undefined) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600">Document not found</p>
      </div>
    );
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "high": return "red";
      case "medium": return "orange";
      case "low": return "green";
      default: return "slate";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">{document.title}</h2>
            <p className="text-slate-600">Compliance Analysis Report</p>
          </div>
        </div>
        
        {analysis && (
          <div className="text-right">
            <div className="text-3xl font-bold text-slate-800">{analysis.overallScore}%</div>
            <div className="text-sm text-slate-500">Overall Compliance</div>
          </div>
        )}
      </div>

      {!analysis ? (
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-8 border border-slate-200 text-center">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-slate-800 mb-2">Analysis in Progress</h3>
          <p className="text-slate-600">Your document is being analyzed. This usually takes 2-3 minutes.</p>
        </div>
      ) : (
        <>
          {/* Executive Summary */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Executive Summary</h3>
            <p className="text-slate-700 leading-relaxed">{analysis.executiveSummary}</p>
          </div>

          {/* Risk Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-red-100">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-semibold text-red-800">High Risk</h4>
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-red-600">
                    {analysis.clauses.filter(c => c.riskLevel === "high").length}
                  </span>
                </div>
              </div>
              <p className="text-sm text-red-700">Critical issues requiring immediate attention</p>
            </div>

            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-orange-100">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-semibold text-orange-800">Medium Risk</h4>
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-orange-600">
                    {analysis.clauses.filter(c => c.riskLevel === "medium").length}
                  </span>
                </div>
              </div>
              <p className="text-sm text-orange-700">Areas for improvement and optimization</p>
            </div>

            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-green-100">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg font-semibold text-green-800">Low Risk</h4>
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-green-600">
                    {analysis.clauses.filter(c => c.riskLevel === "low").length}
                  </span>
                </div>
              </div>
              <p className="text-sm text-green-700">Well-structured compliant sections</p>
            </div>
          </div>

          {/* Detailed Clause Analysis */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-800 mb-6">Detailed Analysis</h3>
            <div className="space-y-6">
              {analysis.clauses.map((clause, index) => (
                <div key={index} className={`border-l-4 border-${getRiskColor(clause.riskLevel)}-500 pl-6 py-4`}>
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-2 py-1 bg-${getRiskColor(clause.riskLevel)}-100 text-${getRiskColor(clause.riskLevel)}-700 rounded-full text-xs font-medium capitalize`}>
                          {clause.riskLevel} Risk
                        </span>
                        <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded-full text-xs font-medium">
                          {clause.category}
                        </span>
                      </div>
                      <blockquote className="text-slate-700 italic bg-slate-50 p-3 rounded-lg mb-3">
                        "{clause.clauseText}"
                      </blockquote>
                    </div>
                    <div className="text-right ml-4">
                      <div className="text-xl font-bold text-slate-800">{clause.riskScore}</div>
                      <div className="text-xs text-slate-500">Risk Score</div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <h5 className="text-sm font-semibold text-slate-800 mb-1">AI Analysis</h5>
                      <p className="text-sm text-slate-700">{clause.aiExplanation}</p>
                    </div>

                    {clause.issues.length > 0 && (
                      <div>
                        <h5 className="text-sm font-semibold text-red-800 mb-2">Issues Identified</h5>
                        <ul className="space-y-1">
                          {clause.issues.map((issue, i) => (
                            <li key={i} className="text-sm text-red-700 flex items-start space-x-2">
                              <span className="text-red-500 mt-1">•</span>
                              <span>{issue}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {clause.recommendations.length > 0 && (
                      <div>
                        <h5 className="text-sm font-semibold text-green-800 mb-2">Recommendations</h5>
                        <ul className="space-y-1">
                          {clause.recommendations.map((rec, i) => (
                            <li key={i} className="text-sm text-green-700 flex items-start space-x-2">
                              <span className="text-green-500 mt-1">✓</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
